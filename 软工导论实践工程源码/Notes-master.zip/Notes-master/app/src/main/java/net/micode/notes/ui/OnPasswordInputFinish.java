package net.micode.notes.ui;

public interface OnPasswordInputFinish {
    void inputFinish();
}
