# The-practice-of-introduction-to-soft-engineering-in-HIT

## 环境：Android Studio、Java 11

小米笔记还算简单，一个多小时就完事了

空巢老人那个项目简直是地狱难度，从凌晨一点部署到凌晨五点，主要还是版本太老，各种不兼容。。

软工导论这课第一次开。。希望这份火炬能帮到之后的同学们吧。
